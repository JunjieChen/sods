package org.apache.james.jdkim;

import junit.framework.TestCase;

import org.apache.james.jdkim.canon.*;
import org.apache.james.jdkim.tagvalue.*;
import org.junit.runner.JUnitCore;
import org.junit.runner.Request;

public class Suite extends TestCase{
	public void testAll(){
		new JUnitCore().run(Request.method(CompoundOutputStreamTest.class, "testSingleBytes"));
		new JUnitCore().run(Request.method(CompoundOutputStreamTest.class, "testChunks"));
		new JUnitCore().run(Request.method(DigestOutputStreamTest.class, "testSingleBytes"));
		new JUnitCore().run(Request.method(DigestOutputStreamTest.class, "testChunksAndPassthrough"));
		new JUnitCore().run(Request.method(DigestOutputStreamTest.class, "testChunks"));
		new JUnitCore().run(Request.method(LimitedOutputStreamTest.class, "testSingleBytes"));
		new JUnitCore().run(Request.method(LimitedOutputStreamTest.class, "testChunks"));
		new JUnitCore().run(Request.method(LimitedOutputStreamTest.class, "testExtensiveChunks"));
		new JUnitCore().run(Request.method(RelaxedBodyCanonicalizerTest.class, "testSingleBytes"));
		new JUnitCore().run(Request.method(RelaxedBodyCanonicalizerTest.class, "testChunks"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testSingleBytes"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testChunks"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testProblematicChunks"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testProblematicCRSequences"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testWrongCRSequencesAdv"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testProblematicEndingCRLFCR"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testProblematicEndingCR"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testExtensiveChunks"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testCRLFchunk"));
		new JUnitCore().run(Request.method(SimpleBodyCanonicalizerTest.class, "testWrongCRSequences"));
		new JUnitCore().run(Request.method(DKIMVerifierTest.class, "testApply"));
		new JUnitCore().run(Request.method(MultiplexingPublicKeyRecordRetrieverTest.class, "testMultiplexingPublicKeyRecordRetriever"));
		new JUnitCore().run(Request.method(MultiplexingPublicKeyRecordRetrieverTest.class, "testMultiplexingPublicKeyRecordRetrieverStringPublicKeyRecordRetriever"));
		new JUnitCore().run(Request.method(MultiplexingPublicKeyRecordRetrieverTest.class, "testAddRetrieverWithOptions"));
		new JUnitCore().run(Request.method(MultiplexingPublicKeyRecordRetrieverTest.class, "testAddRetriever"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testIsHashMethodSupported"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testIsKeyTypeSupported"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testGetAcceptableHashMethods"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testGetAcceptableKeyTypes"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testGetGranularityPattern"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testValidate"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testGetFlags"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testGetPublicKey"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testIsTesting"));
		new JUnitCore().run(Request.method(PublicKeyRecordTest.class, "testIsDenySubdomains"));
		new JUnitCore().run(Request.method(SignatureRecordImplTest.class, "testQPDecode"));
		new JUnitCore().run(Request.method(SignatureRecordImplTest.class, "testExpired"));
		new JUnitCore().run(Request.method(SignatureRecordImplTest.class, "testWrongHashSyntaxes"));
		new JUnitCore().run(Request.method(SignatureRecordImplTest.class, "testQPWhiteSpaces"));
		new JUnitCore().run(Request.method(SignatureRecordImplTest.class, "testQPInvalid"));
		new JUnitCore().run(Request.method(SignatureRecordTest.class, "testBasic"));
		new JUnitCore().run(Request.method(SignatureRecordTest.class, "testWrongOrMissingVersion"));
		new JUnitCore().run(Request.method(SignatureRecordTest.class, "testMissingRequired"));
		new JUnitCore().run(Request.method(SignatureRecordTest.class, "testDomainMismatch"));
		new JUnitCore().run(Request.method(SignatureRecordTest.class, "testMissingFrom"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testInvalidFWSStartSyntax"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testInvalidFWSEndSyntax"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testInvalidSyntax"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testDoubleTag"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testInvalidFWS"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testInvalidFWSSyntax"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testValidFWSTags"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testNoTermination"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testSingleValue"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testWSPinValue"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testFWSinValue"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testEndingWSP"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testTagSetWithEquals"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testEmpty"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testValid"));
		new JUnitCore().run(Request.method(TagValueTest.class, "testNoEqual"));

	}
}
